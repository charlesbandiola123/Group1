<?php
session_start();

if (isset($_SESSION['user_id'])) {
    echo "<h1>Welcome, " . htmlspecialchars($_SESSION['fullname']) . "</h1>";
} else {
    echo "<h1>No user logged in.</h1>";
}
?>
