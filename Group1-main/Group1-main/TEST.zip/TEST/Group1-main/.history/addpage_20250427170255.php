<?php
session_start();
require("connect.php");

$user_id = $_SESSION['user_id'];
$title_id = $_POST['title_id'];

$response = ["status" => "error", "message" => "Unknown error."];

$query1 = "INSERT INTO tblQuizzes (user_id, title_id) VALUES ('$user_id', '$title_id')";
$result1 = mysqli_query($connection, $query1);

if ($result1) {
    $quiz_id = mysqli_insert_id($connection);

    $terms = json_decode($_POST['terms'][0]);
    $definitions = json_decode($_POST['definitions'][0]);

    foreach ($terms as $index => $term) {
        $definition = $definitions[$index];

        $query2 = "INSERT INTO tblQuizTermsAndDefinitions (quiz_id, termss, definitionss) 
                   VALUES ('$quiz_id', '$term', '$definition')";
        $result2 = mysqli_query($connection, $query2);

        if (!$result2) {
            $response = ["status" => "error", "message" => "Failed to insert a term: " . mysqli_error($connection)];
            echo json_encode($response);
            exit();
        }
    }

    $response = ["status" => "success", "message" => "sheeshh awa ang database naa na"];
} else {
    $response = ["status" => "error", "message" => "Failed to insert quiz: " . mysqli_error($connection)];
}

echo json_encode($response);
?>
