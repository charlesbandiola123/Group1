addpage.php:
<?php
    require("connect.php");
    $title_id=$_POST['title_id'];
    

    $query = "INSERT INTO tblQuizzes (title_id) VALUES ('$title_id')";

    $result=mysqli_query($connection, $query);

    if($result){
        echo"<h1>Operation Success</h1>";
    }
    else{
        echo"<h1>Operation Unsuccessful</h1>";
        echo"<h1>Error : " . $query . " " . mysqli_error($connection) . "</h1>";
    }

    ?>