<?php
session_start(); // <-- add this at the very top!

require("connect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Retrieve the user by email
    $stmt = $connection->prepare("SELECT user_id, fullname, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            // Password is correct

            $_SESSION['user_id'] = $row['user_id']; // <-- save user_id in session!

            header("Location: success.php?message=" . urlencode("Welcome, " . $row['fullname']));
            exit();
        }
    }

    // Invalid credentials
    header("Location: login.html?error=" . urlencode("Account not existing"));
    exit();

    $stmt->close();
}

$connection->close();
?>
