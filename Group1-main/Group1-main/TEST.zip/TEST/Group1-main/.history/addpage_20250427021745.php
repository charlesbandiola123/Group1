<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the hidden form inputs sent from the JavaScript (terms, definitions, title)
    $terms = json_decode($_POST['terms[]']); // Decode the terms array from the form input
    $definitions = json_decode($_POST['definitions[]']); // Decode the definitions array
    $title = $_POST['projectTitle']; // The project title from the form

    // Validate the inputs to make sure terms and definitions are provided
    if (empty($terms) || empty($definitions)) {
        echo "Terms and Definitions are required!";
        exit;
    }

    // Database connection setup (replace with your own credentials)
    $conn = new mysqli("localhost", "your_username", "your_password", "your_database");

    // Check if the connection was successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the SQL query to insert the data into the database
    $stmt = $conn->prepare("INSERT INTO tblProjects (title, terms, definitions) VALUES (?, ?, ?)");
    if ($stmt === false) {
        echo "Error preparing the SQL statement.";
        exit;
    }

    // Convert the arrays into JSON strings to save them in the database
    $termsJson = json_encode($terms);
    $definitionsJson = json_encode($definitions);

    // Bind parameters (title, terms, definitions)
    $stmt->bind_param("sss", $title, $termsJson, $definitionsJson);

    // Execute the query
    if ($stmt->execute()) {
        echo "Quiz saved successfully!";
    } else {
        echo "Error saving the quiz: " . $stmt->error;
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();
}
?>
