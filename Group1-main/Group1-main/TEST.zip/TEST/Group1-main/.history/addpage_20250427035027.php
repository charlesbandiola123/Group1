<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $terms = json_decode($_POST['terms[]']);
    $definitions = json_decode($_POST['definitions[]']);
    $projectTitle = $_POST['projectTitle'];

    // Database connection (replace with your connection details)
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'quiz_app';

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert project into tblProjects
    $stmt = $conn->prepare("INSERT INTO tblProjects (title, email) VALUES (?, ?)");
    $stmt->bind_param('ss', $projectTitle, 'example@example.com'); // Change 'example@example.com' to dynamic user email if necessary
    $stmt->execute();
    $project_id = $stmt->insert_id; // Get the auto-generated project_id

    // Insert terms and definitions into tblTermsAndDefinitions
    for ($i = 0; $i < count($terms); $i++) {
        $stmt = $conn->prepare("INSERT INTO tblTermsAndDefinitions (project_id, term, definition) VALUES (?, ?, ?)");
        $stmt->bind_param('iss', $project_id, $terms[$i], $definitions[$i]);
        $stmt->execute();
    }

    $stmt->close();
    $conn->close();

    echo "Data saved successfully!";
}
?>
