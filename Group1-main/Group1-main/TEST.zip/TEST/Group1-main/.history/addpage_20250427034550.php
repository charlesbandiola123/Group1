<?php
include('connect.php'); // Make sure the database connection is included

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title']; // The title of the quiz
    $terms = json_decode($_POST['terms']); // Decoding the terms JSON array
    $definitions = json_decode($_POST['definitions']); // Decoding the definitions JSON array

    // Insert the title into tblQuizzes
    $query = "INSERT INTO tblQuizzes (title_id) VALUES (?)";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $title);
        $stmt->execute();
        $quiz_id = $stmt->insert_id; // Get the ID of the newly inserted quiz
        $stmt->close();

        // Insert terms and definitions into tblQuizTermsAndDefinitions
        $query = "INSERT INTO tblQuizTermsAndDefinitions (quiz_id, termss, definitionss) VALUES (?, ?, ?)";
        if ($stmt = $conn->prepare($query)) {
            foreach ($terms as $key => $term) {
                $definition = $definitions[$key];
                $stmt->bind_param("iss", $quiz_id, $term, $definition);
                $stmt->execute();
            }
            $stmt->close();
        }

        echo "Items saved successfully!";
    } else {
        echo "Error: Could not prepare the SQL statement.";
    }

    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
