<?php
session_start(); // important to access the session
require("connect.php");

$user_id = $_SESSION['user_id'];  // get the logged-in user's ID
$title_id = $_POST['title_id'];

$query = "INSERT INTO tblQuizzes (user_id, title_id) VALUES ('$user_id', '$title_id')";

$result = mysqli_query($connection, $query);

if($result){
    echo "<h1>Operation Success</h1>";
}
else{
    echo "<h1>Operation Unsuccessful</h1>";
    echo "<h1>Error : " . $query . " " . mysqli_error($connection) . "</h1>";
}
?>
