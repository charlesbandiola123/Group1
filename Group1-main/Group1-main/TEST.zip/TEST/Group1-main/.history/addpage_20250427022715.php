<?php
session_start();
require("connect.php");

$user_id = $_SESSION['user_id'];
$title_id = $_POST['title_id'];
$termss = $_POST['termss'];
$definitionss = $_POST['definitionss'];

// 1. Insert into tblQuizzes
$query1 = "INSERT INTO tblQuizzes (user_id, title_id) VALUES ('$user_id', '$title_id')";
$result1 = mysqli_query($connection, $query1);

if($result1){
    // 2. Get the newly created quiz_id
    $quiz_id = mysqli_insert_id($connection);

    // 3. Insert into tblQuizTermsAndDefinitions
    $query2 = "INSERT INTO tblQuizTermsAndDefinitions (quiz_id, termss, definitionss) 
               VALUES ('$quiz_id', '$termss', '$definitionss')";
    $result2 = mysqli_query($connection, $query2);

    if($result2){
        echo "<h1>Operation Success</h1>";
    }
    else{
        echo "<h1>Operation Unsuccessful when inserting into tblQuizTermsAndDefinitions</h1>";
        echo "<h1>Error : " . mysqli_error($connection) . "</h1>";
    }
}
else{
    echo "<h1>Operation Unsuccessful when inserting into tblQuizzes</h1>";
    echo "<h1>Error : " . mysqli_error($connection) . "</h1>";
}
?>
