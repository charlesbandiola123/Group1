<?php

session_start();
require("connect.php");

$user_id = $_SESSION['user_id'];
$title_id = $_POST['title_id'];

// Insert the quiz first
$query1 = "INSERT INTO tblQuizzes (user_id, title_id) VALUES ('$user_id', '$title_id')";
$result1 = mysqli_query($connection, $query1);

if($result1){
    $quiz_id = mysqli_insert_id($connection);

    // Decode the arrays from JSON
    $terms = json_decode($_POST['terms'][0]);
    $definitions = json_decode($_POST['definitions'][0]);

    foreach($terms as $index => $term){
        $definition = $definitions[$index];

        // Updated column names to match 'termss' and 'definitionss'
        $query2 = "INSERT INTO tblQuizTermsAndDefinitions (quiz_id, termss, definitionss) 
                   VALUES ('$quiz_id', '$term', '$definition')";
        $result2 = mysqli_query($connection, $query2);

        if(!$result2){
            echo "Error: " . mysqli_error($connection);
            exit;
        }
    }
    echo "Quiz saved successfully.";
} else {
    echo "Error: " . mysqli_error($connection);
}

?>
