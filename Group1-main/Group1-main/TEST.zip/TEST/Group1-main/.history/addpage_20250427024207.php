<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $title = $_POST['title_id'];
    $terms = json_decode($_POST['terms']);
    $definitions = json_decode($_POST['definitions']);

    // Process and save the data to your database
    // Assuming you have a database connection in `connect.php`
    include('connect.php');

    // Prepare the query to save the quiz title and terms/definitions
    $stmt = $conn->prepare("INSERT INTO tblQuizzes (title) VALUES (?)");
    $stmt->bind_param("s", $title);
    $stmt->execute();
    $quizId = $stmt->insert_id;

    // Save terms and definitions
    foreach ($terms as $key => $term) {
        $definition = $definitions[$key];
        $stmt = $conn->prepare("INSERT INTO tblTermsAndDefinitions (quiz_id, term, definition) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $quizId, $term, $definition);
        $stmt->execute();
    }

    echo "Data saved successfully!";
}
?>
