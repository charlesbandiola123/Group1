<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode terms and definitions
    $terms = json_decode($_POST['terms[]']);
    $definitions = json_decode($_POST['definitions[]']);
    $projectTitle = $_POST['projectTitle'];

    // Database connection (replace with your connection details)
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'quiz_app';

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert project into tblQuizzes (this will give us the quiz_id)
    $stmt = $conn->prepare("INSERT INTO tblQuizzes (title_id, user_id) VALUES (?, ?)"); // Assuming you have the user_id available
    $user_id = 1; // For now, assuming the user_id is 1 (replace with the actual user id from session or login)
    $stmt->bind_param('si', $projectTitle, $user_id);
    $stmt->execute();
    $quiz_id = $stmt->insert_id; // Get the auto-generated quiz_id

    // Insert terms and definitions into tblQuizTermsAndDefinitions
    for ($i = 0; $i < count($terms); $i++) {
        $stmt = $conn->prepare("INSERT INTO tblQuizTermsAndDefinitions (quiz_id, termss, definitionss) VALUES (?, ?, ?)");
        $stmt->bind_param('iss', $quiz_id, $terms[$i], $definitions[$i]);
        $stmt->execute();
    }

    $stmt->close();
    $conn->close();

    echo "Data saved successfully!";
}
?>
